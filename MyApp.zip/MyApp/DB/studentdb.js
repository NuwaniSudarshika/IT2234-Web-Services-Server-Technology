
//array of student JSON details

let  students = [
    {regNo:"2021ict01",name:"Silwa",gender:"male",age:25},
    {regNo:"2021ict02",name:"Nawarathna",gender:"female",age:24},
    {regNo:"2021ict03",name:"Ariyawansha",gender:"female",age:26},
    {regNo:"2021ict04",name:"Wijeykoon",gender:"female",age:25},
    {regNo:"2021ict05",name:"Dayarathna",gender:"female",age:23}
]
module.exports = students;