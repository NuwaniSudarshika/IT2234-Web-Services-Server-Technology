const express = require('express')
const app = express();
const port = 3008;

const students = require('./DB/studentdb');


//01.display all the details of the students.
app.get('/stu',(req,res)=>{
    res.send(students);
});

//02.display the details of the mentioned registration number

app.get('/stu/:id',(req,res)=>{
    const id = req.params.id
    //console.log(id)
    const result = students.find((student)=>student.regNo===id);
    //check student is available or not, if not return an error message 
    if(result){
    res.send(result);
    }
    else{

        res.status(404).send("Status not found");
    }
});

//03.filter student by gender
app.get('/gender/:gen',(req,res)=>{
    const gen = req.params.gen
    //console.log(id)
    const result = students.filter(student=>student.gender===gen);
    res.send(result);
});

//04.filter student by name.
app.get('/name/:name',(req,res)=>{
    const name = req.params.name
    const result = students.filter(student=>student.name===name);
    res.send(result);
});
app.listen(port,()=>{
    console.log(`Server is running on ${port}`);
})